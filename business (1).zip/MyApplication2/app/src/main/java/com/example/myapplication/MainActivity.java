package com.example.myapplication;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Find buttons by ID
        Button qrCodeButton = findViewById(R.id.button6);
        Button facebookButton = findViewById(R.id.button7);
        Button twitterButton = findViewById(R.id.button9);
        Button linkedinButton = findViewById(R.id.button8);
        Button cancelButton = findViewById(R.id.button);
        Button shareButton = findViewById(R.id.button);

        // Set click listeners for the buttons
        qrCodeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Open the QR Code generator URL
                openUrl("https://www.postalytics.com/tools/online-qr-code-generator/");
            }
        });

        facebookButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Open the Facebook URL
                openUrl("https://www.facebook.com/");
            }
        });

        twitterButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Open the Twitter URL
                openUrl("https://www.twitter.com/");
            }
        });

        linkedinButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Open the LinkedIn URL
                openUrl("https://www.linkedin.com/");
            }
        });

        cancelButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Close the app
                finish();
            }
        });


        shareButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Handle Share button click
                Toast.makeText(MainActivity.this, "Share button clicked", Toast.LENGTH_SHORT).show();
            }
        });
    }

    // Helper method to open a URL in a web browser
    private void openUrl(String url) {
        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
        startActivity(intent);
    }
}
